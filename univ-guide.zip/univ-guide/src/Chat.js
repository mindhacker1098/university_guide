function Chat(){
async function damn(){

let d=document.getElementById("damn").value
let lol=await fetch(`https://a29b-2409-4062-17-33c6-5af-9bd8-925b-f30f.in.ngrok.io/ask/${d}`)
let lol1=await lol.text()
document.getElementById("p").value=lol1

}

return (

<div>

<textarea id="damn"></textarea>
<button type="button"onClick={damn}>click</button>


<p id="p"></p>

</div>




);



}
export default Chat;