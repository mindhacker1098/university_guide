import java from "./assets/java.jpg";
import c from "./assets/c++.jpg";
import das from "./assets/dsa.jpg";
import python from "./assets/python.jpg";
import iot from "./assets/iot.jpg";
import webdev from "./assets/web.jpg";
import os from "./assets/os.jpg";
import HeaderNV from "./Header";

function Material() {
	return (
		<div>
			{/* <header className="header-area header-sticky">
				<div className="container">
					<div className="row">
						<div className="col-12">
							<nav className="main-nav">
								<a href="index.html" className="logo">
									Centurion University
								</a>

								<ul className="nav">
									<li className="vt">
										<a
											href="https://tour.concept3d.com/share/7dMdHnQyg/stop/1?mv"
											className="active"
										>
											Virtual Tour
										</a>
									</li>
									<li className="scroll-to-section">
										<a href="#meetings">Events</a>
									</li>

									<li className="has-sub">
										<a href="#mics">mics</a>
										<ul className="sub-menu">
											<li>
												<a href="#almuni.html">Alumni</a>
											</li>
											<li>
												<a href="#teachers.html">Teachers</a>
											</li>
										</ul>
									</li>
									<li className="mat">
										<a href="material.html">Material</a>
									</li>
									<li className="pro">
										<a href="#profile.html">Profile</a>
									</li>
								</ul>
							</nav>
						</div>
					</div>
				</div>
			</header> */}
			{/* <HeaderNV /> */}
			<section className="meetings-page" id="meetings" style={{ height: "1100px" }}>
				<section className="upload" style={{ width: "15%" }}>
					<div style={{ backgroundColor: "azure" }}>
						<from action="/action_page.php">
							<input
								type="file"
								id="myFile"
								name="filename"
								style={{ color: "rgb(46,45,43" }}
							></input>
							<br></br>

							<button>Add book</button>
						</from>
					</div>
				</section>

				<div className="container">
					<div className="row">
						<div className="col-lg-12">
							<div className="row">
								<div className="col-lg-12">
									<div className="filters">
										<ul>
											<li data-filter="*" className="active">
												All books
											</li>
											<li data-filter=".soon">New</li>
											<li data-filter=".imp">Important</li>
											<li data-filter=".att">CSE</li>
										</ul>
									</div>
								</div>
								<div
									style={{ height: "10%", width: "15%", paddingBottom: "8px" }}
								>
									<a href="uuhu.pdf" download>
										<img src={java} alt="" />
									</a>
									<p style={{ backgroundColor: "aquamarine" }}>java </p>
								</div>
								<div
									style={{ height: "10%", width: "15%", paddingBottom: "8px" }}
								>
									<a href="uuhu.pdf" download>
										<img src={c} alt="" />
									</a>
									<p style={{ backgroundColor: "aquamarine" }}>java </p>
								</div>
								<div
									style={{ height: "10%", width: "15%", paddingBottom: "8px" }}
								>
									<a href="uuhu.pdf" download>
										<img src={das} alt="" />
									</a>
									<p style={{ backgroundColor: "aquamarine" }}>java </p>
								</div>
								<div
									style={{ height: "10%", width: "15%", paddingBottom: "8px" }}
								>
									<a href="uuhu.pdf" download>
										<img src={python} alt="" />
									</a>
									<p style={{ backgroundColor: "aquamarine" }}>java </p>
								</div>
								<div
									style={{ height: "10%", width: "15%", paddingBottom: "8px" }}
								>
									<a href="uuhu.pdf" download>
										<img src={iot} alt="" />
									</a>
									<p style={{ backgroundColor: "aquamarine" }}>java </p>
								</div>
								<div
									style={{ height: "10%", width: "15%", paddingBottom: "8px" }}
								>
									<a href="uuhu.pdf" download>
										<img src={webdev} alt="" />
									</a>
									<p style={{ backgroundColor: "aquamarine" }}>java </p>
								</div>
								<div style={{ height: "10%", width: "15%" }}>
									<a href="uuhu.pdf" download>
										<img src={os} alt="" />
									</a>
									<p style={{ backgroundColor: "aquamarine" }}>java </p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		</div>
	);
}

export default Material;
