import ALUON from "./assets/almuni1.jpg"
import ALUTW from "./assets/almuni2.jpeg"
import ALUTH from "./assets/almuni3.jpg"
import ALUFR from "./assets/almuni4.jpg"
import ALUFV from "./assets/almuni5.jpg"
function Alumnis() {
  return (
    <section className="our-courses" id="courses">
      <div className="container">
        <div className="row">
          <div className="col-lg-12">
            <div className="section-heading">
              <h2>Our Top Alumnis</h2>
            </div>
          </div>
          <div className="col-lg-12">
            <div className="owl-courses-item owl-carousel">
              <div className="item">
                <img src={ALUON} alt="Course One" />
                <div className="down-content">
                  <h4>I got placed in xyz due to centurion</h4>
                  <div className="info">
                    <div className="row">
                      <div className="col-8">
                        <p>centurion rating</p>
                        <ul>
                          <li><i className="fa fa-star"></i></li>
                          <li><i className="fa fa-star"></i></li>
                          <li><i className="fa fa-star"></i></li>
                          <li><i className="fa fa-star"></i></li>
                          <li><i className="fa fa-star"></i></li>
                        </ul>
                      </div>
                      <div className="col-4">
                        <span>salary 100k</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="item">
                <img src={ALUTW} alt="Course Two" />
                <div className="down-content">
                  <h4>I got my dream job due to centurion</h4>
                  <div className="info">
                    <div className="row">
                      <div className="col-8">
                        <p>centurion rating</p>
                        <ul>
                          <li><i className="fa fa-star"></i></li>
                          <li><i className="fa fa-star"></i></li>
                          <li><i className="fa fa-star"></i></li>
                        </ul>
                      </div>
                      <div className="col-4">
                        <span>salary 150k</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="item">
                <img src={ALUTH} alt="" />
                <div className="down-content">
                  <h4>Centurion is a right place for all your dreams</h4>
                  <div className="info">
                    <div className="row">
                      <div className="col-8">
                        <p>centurion rating</p>
                        <ul>
                          <li><i className="fa fa-star"></i></li>
                          <li><i className="fa fa-star"></i></li>
                          <li><i className="fa fa-star"></i></li>
                          <li><i className="fa fa-star"></i></li>
                        </ul>
                      </div>
                      <div className="col-4">
                        <span>salary 100k</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="item">
                <img src={ALUFR} alt="" />
                <div className="down-content">
                  <h4>centurion is the reason for where im right now</h4>
                  <div className="info">
                    <div className="row">
                      <div className="col-8">
                        <p>centurion rating</p>
                        <ul>
                          <li><i className="fa fa-star"></i></li>
                          <li><i className="fa fa-star"></i></li>
                          <li><i className="fa fa-star"></i></li>
                          <li><i className="fa fa-star"></i></li>
                          <li><i className="fa fa-star"></i></li>
                        </ul>
                      </div>
                      <div className="col-4">
                        <span>salary 145k</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="item">
                <img src={ALUFV} alt="" />
                <div className="down-content">
                  <h4>i love centurion</h4>
                  <div className="info">
                    <div className="row">
                      <div className="col-8">
                        <p>centurion rating</p>
                        <ul>
                          <li><i className="fa fa-star"></i></li>
                          <li><i className="fa fa-star"></i></li>
                          <li><i className="fa fa-star"></i></li>
                          <li><i className="fa fa-star"></i></li>
                          <li><i className="fa fa-star"></i></li>
                        </ul>
                      </div>
                      <div className="col-4">
                        <span>salary 90k</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="item">
                <img src="almuni1.jpg" alt="" />
                <div className="down-content">
                  <h4>centurion is the right place</h4>
                  <div className="info">
                    <div className="row">
                      <div className="col-8">
                        <p>centurion rating</p>
                        <ul>
                          <li><i className="fa fa-star"></i></li>
                          <li><i className="fa fa-star"></i></li>
                          <li><i className="fa fa-star"></i></li>
                          <li><i className="fa fa-star"></i></li>
                          <li><i className="fa fa-star"></i></li>
                        </ul>
                      </div>
                      <div className="col-4">
                        <span>salary 140k</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>





              <div className="item">
                <img src="almuni1.jpg" alt="" />
                <div className="down-content">
                  <h4>Centurion is as best as tier 1 colleges</h4>
                  <div className="info">
                    <div className="row">
                      <div className="col-8">
                        <p>centurion rating</p>
                        <ul>
                          <li><i className="fa fa-star"></i></li>
                          <li><i className="fa fa-star"></i></li>
                          <li><i className="fa fa-star"></i></li>
                          <li><i className="fa fa-star"></i></li>
                          <li><i className="fa fa-star"></i></li>
                        </ul>
                      </div>
                      <div className="col-4">
                        <span>salary 120k</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>


  );
}

export default Alumnis;