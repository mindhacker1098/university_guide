import HeaderNV from './Header';
import EventCUTM from './Events';
import AlumnisCT from './Alumnis';
// import FooterFT from './components/Footer';
// import MaterialMT from './components/Material';
import Body from './Body';
import { Link, BrowserRouter as Router, Routes, Route } from "react-router-dom";
//import Body from './components/Body';


function Home() {


    return (
        <>

            <Body />
            <EventCUTM />
            <AlumnisCT />



        </>
    )
}

export default Home