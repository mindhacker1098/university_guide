
import BGONE from "./assets/backcent.jpg"
import BGTWO from "./assets/centmba.jpg"
import BGTHR from "./assets/centmba2.jpg"
import BGFOR from "./assets/meeting-04.jpg"

function Event() {
	return (
		<div>
			<section className="upcoming-Events" id="meetings">
				<div className="container">
					<div className="row">
						<div className="col-lg-12">
							<div className="section-heading">
								<h2>Upcoming Meetings</h2>
							</div>
						</div>
						<div className="col-lg-4">
							<div className="categories">
								<h4>Events categories</h4>
								<ul>
									<li>
										<a href="#cultural">Cultural</a>
									</li>
									<li>
										<a href="#fests">Fests</a>
									</li>
									<li>
										<a href="#sports">Sports</a>
									</li>
									<li>
										<a href="#webinar">Webinars</a>
									</li>
								</ul>
								<div className="main-button-redd">
									<link
										href="https://fonts.googleapis.com/icon?family=Material+Icons"
										rel="stylesheet"
									/>
									<div className="floating-container">
										<div className="floating-button" style={{ color: "red" }}>
											<i className="material-icons">
												<span className="material-symbols-outlined">
													psychology_alt
												</span>
											</i>
											<p>faq</p>
										</div>
										<div className="element-container"></div>
									</div>
									<a href="meetings.html">All Upcoming Events</a>
								</div>
							</div>

						</div>
						<div className="col-lg-8">
							<div className="row">
								<div className="col-lg-6">
									<div className="meeting-item">
										<div className="thumb">
											<div className="price">
												<span>monday</span>
											</div>
											<a href="meeting-details.html">
												<img src={BGONE} alt="New Lecturer Meeting" />
											</a>
										</div>
										<div className="down-content">
											<div className="date">
												<h6>
													Nov <span>10</span>
												</h6>
											</div>
											<a href="meeting-details.html">
												<h4>Gajajyoti 2k22</h4>
											</a>
											<p>
												Enjoy the night with full fun
												<br />
												Your centurion.
											</p>
										</div>
									</div>
								</div>
								<div className="col-lg-6">
									<div className="meeting-item">
										<div className="thumb">
											<div className="price">
												<span>Tuesday</span>
											</div>
											<a href="meeting-details.html">
												<img src={BGTWO} alt="Online Teaching" />
											</a>
										</div>
										<div className="down-content">
											<div className="date">
												<h6>
													Nov <span>24</span>
												</h6>
											</div>
											<a href="meeting-details.html">
												<h4>Cultural night </h4>
											</a>
											<p>
												Bring light to different cultural fest of india
												<br />
												Centurion University
											</p>
										</div>
									</div>
								</div>
								<div className="col-lg-6">
									<div className="meeting-item">
										<div className="thumb">
											<div className="price">
												<span>Sunday</span>
											</div>
											<a href="meeting-details.html">
												<img src={BGTHR} alt="Higher Education" />
											</a>
										</div>
										<div className="down-content">
											<div className="date">
												<h6>
													Nov <span>26</span>
												</h6>
											</div>
											<a href="meeting-details.html">
												<h4>Annual sports</h4>
											</a>
											<p>
												show the spirit of game
												<br />
												Centurion University.
											</p>
										</div>
									</div>
								</div>
								<div className="col-lg-6">
									<div className="meeting-item">
										<div className="thumb">
											<div className="price">
												<span>Friday</span>
											</div>
											<a href="meeting-details.html">
												<img
													src={BGFOR}
													alt="Student Training"
												/>
											</a>
										</div>
										<div className="down-content">
											<div className="date">
												<h6>
													Nov <span>30</span>
												</h6>
											</div>
											<a href="meeting-details.html">
												<h4>NCC Camp</h4>
											</a>
											<p>
												All NCC students you have a camp this month
												<br />
												Centurion University
											</p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="main-button-red">
					<a href="meetings.html">more Events</a>

				</div>
			</section>
		</div>
	);
}
export default Event;
