
import  "./chat.css";

import React, { useEffect} from "react";
import { Link } from "react-router-dom";
function Meeting() {
	var dta=new Date().toJSON().slice(0,10)
	let url =`http://localhost:8080/damn?date=${dta}`;
	let b=0;
	  
    function Do(){
     
	  console.log(dta);
        
		


const mon=["jan","feb","mar","apr","may","jun","jul","aug","sept","oct","nov","dec"];
function Dat(d){
	return new Intl.DateTimeFormat('en-Us', { weekday:'long'}).format(new Date(d))
	}



        const fetchData = async () => {
            try {
				b++;
              if(b==2){return}
              let a=document.getElementById("damn");
            
                const response = await fetch(url);
                const data = await response.json();
                for(let i=0;i<data.length;i++){
                    let name=data[i].name; 
                    let date=data[i].date;
                    let desp=data[i].desp;
					let plac=data[i].plac;

console.log(date);

                    let str=data[i].data
const b=await fetch(`data:image/png;base64,${str}`);
  const blob=await b.blob(); 
const iurl= URL.createObjectURL(blob);


let day=Dat(`${date.slice(5,7)}/${date.slice(8,10)}/${date.slice(0,4)}`);


                a.innerHTML=a.innerHTML+`<div class="col-lg-4 templatemo-item-col all soon">
				<div class="meeting-item">
					<div class="thumb">
						<div class="price">
							<span>`+day+`</span>
						</div>
						<a href="meeting-details.html">
							<img src=`+iurl+` alt="" height="300" width="300"/>
						</a>
					</div>
					<div class="down-content">
						<div class="date">
							<h6>
								`+mon[date.slice(5,7)-1]+` <span>`+date.slice(8,10)+`</span>
							</h6>
						</div>
						<a href="/eventlist">
							<h4>`+name+`</h4>
						</a>
						<p>
							`+desp+`
							<br />
							${plac}
						</p>
					</div>
				</div>
			</div>`}


            } catch (error) {
                console.log("error", error);
            }
        };

        fetchData();
    }



useEffect(()=>{

	Do();
},[])



	return (
		<div>
			<section className="meetings-page" id="meetings">
				<div className="container">
					<div className="row">
						<div className="col-lg-12">
							<div className="row">
								<div className="col-lg-12">
									<div className="filters">
										<ul>
											<li data-filter="*" className="active" onClick={()=>{url=`http://localhost:8080/img`;
											
											document.getElementById("damn").innerHTML=""
											Do()
											
											
											}}>
												All Events
											</li>
											<li><Link to="/damn">Add event</Link></li>
										</ul>
									</div>
								</div>
								<div className="col-lg-12">
									<div className="row grid" id="damn">






							

















									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>

			<button className="open-button" type="button" onClick={()=>{
				document.getElementById("myForm").style.display = "block";}}></button>

<div className="chat-popup" id="myForm">
	<div id="x">damn bro
	
	<span onClick={()=>{		document.getElementById("myForm").style.display = "none";}} id="X">X</span>
	
	</div>

<div id="body-part">








</div>
<div class="chat-input">      
      <form>
        <input type="text" id="chat-input" placeholder="Send a message..."/>
      <button type="button" class="chat-submit" id="chat-submit" onClick={


async()=>{

let v=document.getElementById("chat-input").value;
document.getElementById("body-part").innerHTML+=`<div class="rig">${v}</div>`
let lol=await fetch(`http://localhost:5000/ask/${v}`)
let lol1=await lol.text()
document.getElementById("body-part").innerHTML+=`<div class="lef">${lol1}</div>`

document.getElementById("chat-input").value="";
}


	  }><i class="material-icons">send</i></button>
      </form>      
    </div>
	
</div>







		</div>
	);
}



export default Meeting;