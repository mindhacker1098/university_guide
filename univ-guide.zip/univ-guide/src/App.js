
import './App.css';
import HeaderNV from './components/Header';
import EventCUTM from './components/Events';
import AlumnisCT from './components/Alumnis';
import FooterFT from './components/Footer';
import Material from './components/Material';
import { Link, BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Body from './components/Body';
import Home from './components/Home';
import EVentList from './components/Event-list';
import Alumnis from './components/Alumnis';
import Meeting from './components/Meeting';
import Login from './Login';
import Shakthi from './Shakthi';
import Reg from './Reg';
import Chat from './Chat';

function App() {
  return (
    <div>
      <Router>
        <HeaderNV />
        {/* <Link className="btn btn-outline-light" to="/adduser">
Register
</Link><br></br>
<Link className="btn btn-outline-light" to="/material">
Material
</Link><br></br> */}
        {/* <Link className="btn btn-outline-light" to="/log">
Login
</Link> */}

        <Routes>

          <Route exact path="/alumni" element={<Alumnis />} />
          {/* <Route exact path="/adduser" element={<Registerr />} /> */}


          {/* <Route exact path="/edituser/:id" element={<EditUser />} />
<Route exact path="/viewuser/:id" element={<ViewUser />} /> */}

          <Route exact path="/material" element={<Material />} />
          <Route exact path="/meeting" element={<Meeting/>} />
          <Route exact path="/eventlist" element={<EVentList />} />
          <Route exact path="/" element={<Login />} />
          <Route exact path="/damn" element={<Shakthi />} />
          <Route exact path="/Home" element={<Home/>}/>
          <Route exact path="/Reg" element={<Reg/>}/>
          <Route exact path="/Chat" element={<Chat/>}/>
          

          
        </Routes>

      </Router>





      {/* <MaterialMT /> */}
      {/* <FooterFT /> */}


    </div>
  );
}

export default App;
