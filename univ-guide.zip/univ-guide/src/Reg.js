import React from 'react';
function Reg(){

async function damn(){

let name=document.getElementById("name").value;
document.getElementById("name").value="";

let reg=document.getElementById("reg").value;
document.getElementById("reg").value="";

let pass=document.getElementById("pass").value;
document.getElementById("pass").value="";


await fetch(`http://localhost:8080/reg?name=${name}&reg=${reg}&pass=${pass}`);


}





return (

<div>


<form>
name
<input type="text" id="name"/>
registration
<input type="text" id="reg"/>
password
<input type="text" id="pass"/>
<button type="button"onClick={damn}>click</button>

</form>




</div>




);




}
export default Reg;