import {useState} from "react";
import "./Add.css"
function Add(){
    const [val,setVal]=useState("");
async function lol(){

let name=document.getElementById("name").value;
document.getElementById("name").value="";
let date=document.getElementById("date").value;
document.getElementById("date").value="";
let file=document.getElementById("file").files[0];
document.getElementById("file").value="";
document.getElementById("date").value="";
let desp=document.getElementById("desp").value;
document.getElementById("desp").value="";
let url = "http://localhost:8080/file";
  let data = {
    "name": name,
    "date": date,
    "file": file,
    "desp": desp
  }


  const formData = new FormData();

  for (const name in data) {
    formData.append(name, data[name]);
  }

  const response = await fetch(url, {
    method: 'POST',
    body: formData
  });
setVal("name");

}

return (

    <div id="add1">
        <div id="add">
 Enter event Name<br></br>   
<input type="text" id="name"></input><br></br>
Select date<br></br>
<input type="date" id="date"></input><br></br>
Event Description
<br></br>
<textarea rows="5" cols="40" id="desp" placeholder="write here"></textarea><br></br>
<input type="file" id="file"></input><br></br>
<button onClick={lol}>Add</button>
</div>
</div>


);


}
export default Add;