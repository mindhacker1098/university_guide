package com.example.demoservice;




import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demomodel.employee;
import com.example.demorepo.employeeReprository;


@Service

public class employeeService {
  
  @Autowired
  public employeeReprository employeeRepo;
public List<employee> getAllEmployees()
{
  List<employee> emp=new ArrayList<>();
  employeeRepo.findAll().forEach(emp::add);
  return emp;
}
public void addEmployee(employee emp) {
    employeeRepo.save(emp);
  }
  
  public void updateEmployee(String id, employee emp) {
  
    employeeRepo.save(emp);
  }
  
  public void deleteEmployee(String id) {
    employeeRepo.deleteById(id);
  }
  
  
  
}