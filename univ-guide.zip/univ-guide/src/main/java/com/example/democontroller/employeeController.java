package com.example.democontroller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demomodel.employee;
import com.example.demoservice.employeeService;



@RestController

public class employeeController 
{
  @Autowired
  private employeeService empserv;
  @RequestMapping("/employee")
        public List<employee> getAllemployees()
        {
          return empserv.getAllEmployees();
          
        }
        @PostMapping("/")
        public void addEmployee(@RequestBody employee emp) 
        {
          empserv.addEmployee(emp);
          
        }
        @PutMapping("/{id}")
        public void updateEmployee(@PathVariable String id,@RequestBody employee emp) 
        {
          empserv.updateEmployee(id,emp);
          
        }
        @DeleteMapping("/{id}")
        public void deleteEmployee(@PathVariable String id) 
        {
          empserv.deleteEmployee(id);
          
        }
        
        
        
    
  
  
}