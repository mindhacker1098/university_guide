package com.example.demorepo;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.demomodel.employee;



@Repository
public interface employeeReprository extends CrudRepository <employee, String>{

  
}