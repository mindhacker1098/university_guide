import React from 'react';
import ReactDOM from 'react-dom/client';
import Add from './Add';

import App from './App';
import Login from './Login';
import Reg from './Reg';
// import MaterialMT from './components/Material';
// import EVentList from './components/Event-list';


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App/>
    {/* <MaterialMT/> */}
    {/* <EVentList/> */}
  </React.StrictMode>
);

