<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>header</title>
</head>
<body>
    <?php echo"
<header class="header-area header-sticky">
      <div class="container">
          <div class="row">
              <div class="col-12">
                  <nav class="main-nav">
                      <!-- ***** Logo Start ***** -->
                      <a href="index.html" class="logo">
                          Centurion Guide
                      </a>
                      <!-- ***** Logo End ***** -->
                      <!-- ***** Menu Start ***** -->
                      <ul class="nav">
                          <li><a href="index.html">home</a></li>
                          <li><a href="#virtual.html">virtual tour</a></li>
                          <li><a href="meetings.html" class="active">events</a></li>
                         
                          <li class="has-sub">
                              <a href="javascript:void(0)">misc</a>
                              <ul class="sub-menu">
                                  <li><a href="#almuni.html">Almuni</a></li>
                                  <li><a href="#teachers.html">Teachers</a></li>
                              </ul>
                          </li>
                          <li><a href="#material.html">Material</a></li> 
                          <li><a href="#profile.html">Profile</a></li> 
                      </ul>        
                      <a class='menu-trigger'>
                          <span>Menu</span>
                      </a>
                      <!-- ***** Menu End ***** -->
                  </nav>
              </div>
          </div>
      </div>
  </header>


</body>
</html>