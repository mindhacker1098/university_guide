import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, useParams } from "react-router-dom";
import HeaderNV from "./Header";
import Navbar from "./Navbar";

// import './Table.css';
import './View.css';
export default function View() {

  const [docs, setUsers] = useState([]);



  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    const result = await axios.get("http://localhost:9999/users");
    setUsers(result.data);
  };

  const deleteUser = async (id) => {
    await axios.delete(`http://localhost:9999/user/${id}`);
    loadUsers();
  };

  return (
    <div>
      <HeaderNV />
      <Navbar />
      <div className="containera">
        <div className="py-4">
          <table className="table-border-shadow">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">NAME</th>
                <th scope="col">ADDRESS</th>
                <th scope="col">PHONE</th>
                <th scope="col">MAIL</th>
                <th scope="col">ACTION</th>

              </tr>
            </thead>
            <tbody>
              {docs.map((doc) => (
                <tr key={doc.id} >
                  <td>{doc.id}</td>
                  <td>{doc.name}</td>
                  <td>{doc.address}</td>
                  <td>{doc.phone}</td>
                  <td>{doc.mail}</td>
                  <td>
                    <Link
                      className="btn btn-outline-primary mx-2"
                      to={`/adde`}
                    >
                      Edit
                    </Link>
                    <button
                      className="btn btn-danger mx-2"
                      onClick={() => deleteUser(doc.id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
