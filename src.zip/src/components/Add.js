import axios from "axios";
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import './Add.css';

export default function Adde() {


  let navigate = useNavigate();
  const [id, setId] = useState();
  const [name, setName] = useState();
  const [address, setAddress] = useState("");
  const [phone, setPhone] = useState("");
  const [mail, setMail] = useState("");

  const onSubmit = (e) => {
    const user = { id, name, address, phone, mail }
    e.preventDefault();
    fetch("http://localhost:9999/user", {
      method: 'POST',
      headers: { "content-type": "application/json" },
      body: JSON.stringify(user)
    }).then(() => {
      navigate("/view");
    })

  };


  return (
    <div className="f-main">
      <div className="f-main2">
        <div className="f-header">
          <h1>ADD CONTACT</h1>
        </div>

        <div className="f-contents">

          <div className="f-inputs">


            <input className="f-input"
              placeholder="ID"
              name="id"
              value={id}
              onChange={(e) => setId(e.target.value)}
            />

            <input className="f-input"
              placeholder="Name"
              name="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />

            <input className="f-input"
              placeholder="Address"
              name="address"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
            />



            <button type="submit" className="fb" to="/" onClick={onSubmit}>SUBMIT</button>

          </div>

          <div className="f-inputs">

            <input className="f-input"
              placeholder="phone"
              name="phone"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
            />

            <input className="f-input"
              placeholder="mail"
              name="mail"
              value={mail}
              onChange={(e) => setMail(e.target.value)}
            />

            <Link type="submit" className="fb-cancel2" to="/" >CANCEL</Link>
          </div>

        </div>
      </div>
    </div>
  )
}
