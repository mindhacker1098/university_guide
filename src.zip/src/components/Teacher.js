import "./teacherrr.css";
import BG from "./assets/course.png";
import el from "./assets/elon.jfif";
import CUTMLOGO from "./assets/CUTM_Logo-removebg-preview.png"
// import "./Icon.css"
// import './profileteach.css';
// import './teacherrr.css';

import TCON from "./assets/DINESH-SHARMA-3.jpg"
import TCTW from "./assets/PP_recent.jpg"
import HeaderNV from './Header'

function TeacherTC() {
    return (
        <div>
            <HeaderNV />

            <section className="meetings-page" id="meetings" >



                {/* <div className="container">
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="row">
                                <div className="col-lg-12">
                                    <div className="filters">
                                        <ul>
                                            <li data-filter="*" className="active">
                                                All books
                                            </li>
                                            <li data-filter=".soon">New</li>
                                            <li data-filter=".imp">Important</li>
                                            <li data-filter=".att">CSE</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> */}

                <div className="container">
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="row">
                                <div className="col-lg-12">
                                    <div className="filters">
                                        <ul>
                                            <li data-filter="*" className="active">
                                                All Teachers
                                            </li>
                                            <li data-filter=".soon">CSE</li>
                                            <li data-filter=".imp">ECE</li>
                                            <li data-filter=".att">Agriculture</li>
                                            <li ><a href="/ada"> Add Teacher</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div className="gridd">

                    <div className="picc">
                        <div className="picdes">
                            {/* <img src="elon.jfif" alt="Avatar" class="image" style="width:100%"> */}

                            <img
                                className="imgel"
                                style={{ width: "100%" }}
                                src={el}
                                alt=""
                            />
                            <div className="middle">
                                <div className="text">Elon Musk</div>
                                <p>5 year experience</p>
                                <p>CSE</p>
                            </div>

                            <p>contact 9337144828</p>

                        </div>
                    </div>
                </div>



                <div className="gridd">

                    <div className="picc">
                        <div className="picdes">
                            {/* <img src="elon.jfif" alt="Avatar" class="image" style="width:100%"> */}

                            <img
                                className="imgel"
                                style={{ width: "100%" }}
                                src={el}
                                alt=""
                            />
                            <div className="middle">
                                <div className="text">Elon Musk</div>
                                <p>5 year experience</p>
                                <p>CSE</p>
                            </div>

                            <p>contact 9337144828</p>

                        </div>
                    </div>
                </div>
                <div className="gridd">

                    <div className="picc">
                        <div className="picdes">
                            {/* <img src="elon.jfif" alt="Avatar" class="image" style="width:100%"> */}

                            <img
                                className="imgel"
                                style={{ width: "100%" }}
                                src={el}
                                alt=""
                            />
                            <div className="middle">
                                <div className="text">Elon Musk</div>
                                <p>5 year experience</p>
                                <p>CSE</p>
                            </div>

                            <p>contact 9337144828</p>

                        </div>
                    </div>
                </div>
                <div className="gridd">

                    <div className="picc">
                        <div className="picdes">
                            {/* <img src="elon.jfif" alt="Avatar" class="image" style="width:100%"> */}

                            <img
                                className="imgel"
                                style={{ width: "100%" }}
                                src={el}
                                alt=""
                            />
                            <div className="middle">
                                <div className="text">Elon Musk</div>
                                <p>5 year experience</p>
                                <p>CSE</p>
                            </div>

                            <p>contact 9337144828</p>

                        </div>
                    </div>
                </div>
                <div className="gridd">

                    <div className="picc">
                        <div className="picdes">
                            {/* <img src="elon.jfif" alt="Avatar" class="image" style="width:100%"> */}

                            <img
                                className="imgel"
                                style={{ width: "100%" }}
                                src={el}
                                alt=""
                            />
                            <div className="middle">
                                <div className="text">Elon Musk</div>
                                <p>5 year experience</p>
                                <p>CSE</p>
                            </div>

                            <p>contact 9337144828</p>

                        </div>
                    </div>
                </div>
                <div className="gridd">

                    <div className="picc">
                        <div className="picdes">
                            {/* <img src="elon.jfif" alt="Avatar" class="image" style="width:100%"> */}

                            <img
                                className="imgel"
                                style={{ width: "100%" }}
                                src={el}
                                alt=""
                            />
                            <div className="middle">
                                <div className="text">Elon Musk</div>
                                <p>5 year experience</p>
                                <p>CSE</p>
                            </div>

                            <p>contact 9337144828</p>

                        </div>
                    </div>
                </div>
                <div className="gridd">

                    <div className="picc">
                        <div className="picdes">
                            {/* <img src="elon.jfif" alt="Avatar" class="image" style="width:100%"> */}

                            <img
                                className="imgel"
                                style={{ width: "100%" }}
                                src={el}
                                alt=""
                            />
                            <div className="middle">
                                <div className="text">Elon Musk</div>
                                <p>5 year experience</p>
                                <p>CSE</p>
                            </div>

                            <p>contact 9337144828</p>

                        </div>
                    </div>
                </div>
                <div className="gridd">

                    <div className="picc">
                        <div className="picdes">
                            {/* <img src="elon.jfif" alt="Avatar" class="image" style="width:100%"> */}

                            <img
                                className="imgel"
                                style={{ width: "100%" }}
                                src={el}
                                alt=""
                            />
                            <div className="middle">
                                <div className="text">Elon Musk</div>
                                <p>5 year experience</p>
                                <p>CSE</p>
                            </div>

                            <p>contact 9337144828</p>

                        </div>
                    </div>
                </div>
                <div className="gridd">

                    <div className="picc">
                        <div className="picdes">
                            {/* <img src="elon.jfif" alt="Avatar" class="image" style="width:100%"> */}

                            <img
                                className="imgel"
                                style={{ width: "100%" }}
                                src={el}
                                alt=""
                            />
                            <div className="middle">
                                <div className="text">Elon Musk</div>
                                <p>5 year experience</p>
                                <p>CSE</p>
                            </div>

                            <p>contact 9337144828</p>

                        </div>
                    </div>
                </div>
                <div className="gridd">

                    <div className="picc">
                        <div className="picdes">
                            {/* <img src="elon.jfif" alt="Avatar" class="image" style="width:100%"> */}

                            <img
                                className="imgel"
                                style={{ width: "100%" }}
                                src={el}
                                alt=""
                            />
                            <div className="middle">
                                <div className="text">Elon Musk</div>
                                <p>5 year experience</p>
                                <p>CSE</p>
                            </div>

                            <p>contact 9337144828</p>

                        </div>
                    </div>
                </div>


                {/* <div className="containerr">
                    <div className="containerr1">
                        <div className="frontt" >
                            <img
                                className="img-s"
                                style={{ height: "110px", width: "109px" }}
                                src={TCON}
                                alt=""
                            />
                            <p>Assignment</p>
                        </div>

                    </div>
                </div>
                <div className="containerr1">
                    <div className="frontt" style={{ textAlign: "center" }}>
                        <img
                            className="img-s"
                            style={{ height: "110px", width: "109px" }}
                            src={TCON}
                            alt=""
                        />
                        <p>Assignment</p>
                    </div>


                    <div className="tech">

                        <div className="columnn">
                            <div class="cardd" style={{ width: "160px", height: "175px" }}>
                                <img src={TCON} alt="Avatar" style={{ width: "150px", height: "90px" }} />
                                <div className="containerr">
                                    <h4><b>person-1</b></h4>
                                    <p>Engineer<br />5Years Experience</p>

                                </div>
                            </div>

                        </div>


                        <div className="columnn">
                            <div class="cardd" style={{ width: "160px", height: "175px" }}>
                                <img src={TCON} alt="Avatar" style={{ width: "150px", height: "90px" }} />
                                <div className="containerr">
                                    <h4><b>person-1</b></h4>
                                    <p>Engineer<br />5Years Experience</p>

                                </div>
                            </div>

                        </div>

                    </div>



                    <div class="row">
                        <div class="column">
                            <div class="cardd">
                                <h3>cardd 1</h3>
                                <p>Some text</p>
                                <p>Some text</p>
                            </div>
                        </div>

                        <div class="column">
                            <div class="cardd">
                                <h3>cardd 2</h3>
                                <p>Some text</p>
                                <p>Some text</p>
                            </div>
                        </div>

                        <div class="column">
                            <div class="cardd">
                                <h3>cardd 3</h3>
                                <p>Some text</p>
                                <p>Some text</p>
                            </div>
                        </div>

                        <div class="column">
                            <div class="cardd">
                                <h3>cardd 4</h3>
                                <p>Some text</p>
                                <p>Some text</p>
                            </div>
                        </div>
                    </div>
                    <div id="login-container">
                        <div class="profile-img"></div>
                        <h1>
                            Maddie
                        </h1>
                        <div class="description">
                            Maddie is a front end web developer in New York. She has worked in the field for 10 years now. Check out her projects in the links below. She is available for hire as well.
                        </div>
                        <div class="social">
                            <a>GitHub</a>
                            <a>Twitter</a>
                            <a>LinkedIn</a>
                        </div>


                    </div>

                    <div id="login-container">
                        <div class="profile-img"></div>
                        <h1>
                            Maddie
                        </h1>
                        <div class="description">
                            Maddie is a front end web developer in New York. She has worked in the field for 10 years now. Check out her projects in the links below. She is available for hire as well.
                        </div>
                        <div class="social">
                            <a>GitHub</a>
                            <a>Twitter</a>
                            <a>LinkedIn</a>
                        </div>


                    </div>
                    <div id="login-container">
                        <div class="profile-img"></div>
                        <h1>
                            Maddie
                        </h1>
                        <div class="description">
                            Maddie is a front end web developer in New York. She has worked in the field for 10 years now. Check out her projects in the links below. She is available for hire as well.
                        </div>
                        <div class="social">
                            <a>GitHub</a>
                            <a>Twitter</a>
                            <a>LinkedIn</a>
                        </div>


                    </div>
                    <div id="login-container">
                        <div class="profile-img"></div>
                        <h1>
                            Maddie
                        </h1>
                        <div class="description">
                            Maddie is a front end web developer in New York. She has worked in the field for 10 years now. Check out her projects in the links below. She is available for hire as well.
                        </div>
                        <div class="social">
                            <a>GitHub</a>
                            <a>Twitter</a>
                            <a>LinkedIn</a>
                        </div>


                    </div>
                    <div id="login-container">
                        <div class="profile-img"></div>
                        <h1>
                            Maddie
                        </h1>
                        <div class="description">
                            Maddie is a front end web developer in New York. She has worked in the field for 10 years now. Check out her projects in the links below. She is available for hire as well.
                        </div>
                        <div class="social">
                            <a>GitHub</a>
                            <a>Twitter</a>
                            <a>LinkedIn</a>
                        </div>


                    </div>
                    <div id="login-container">
                        <div class="profile-img"></div>
                        <h1>
                            Maddie
                        </h1>
                        <div class="description">
                            Maddie is a front end web developer in New York. She has worked in the field for 10 years now. Check out her projects in the links below. She is available for hire as well.
                        </div>
                        <div class="social">
                            <a>GitHub</a>
                            <a>Twitter</a>
                            <a>LinkedIn</a>
                        </div>


                    </div>
                    <div id="login-container">
                        <div class="profile-img"></div>
                        <h1>
                            Maddie
                        </h1>
                        <div class="description">
                            Maddie is a front end web developer in New York. She has worked in the field for 10 years now. Check out her projects in the links below. She is available for hire as well.
                        </div>
                        <div class="social">
                            <a>GitHub</a>
                            <a>Twitter</a>
                            <a>LinkedIn</a>
                        </div>


                    </div>
                </div > */}
            </section >




        </div >

    );
}

export default TeacherTC;
