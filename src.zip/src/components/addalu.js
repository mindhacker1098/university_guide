import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import './Imagee.css'
import HeaderNV from './Header'
// import { useDispatch, useSelector } from "react-redux";
// import { uploadImage } from "./uploadAction";

function Addalu() {
    const [file, setFile] = useState();
    function handleChange(e) {
        console.log(e.target.files);
        setFile(URL.createObjectURL(e.target.files[0]));
    }

    // const Imagee = () => {

    // const classes = useStyles();
    // const dispatch = useDispatch();
    // //const [imagePreview, setImagePreview] = useState(null);
    // const [imageData, setImageData] = useState(null);
    // const [imageName, setImageName] = useState("");
    // //const { image } = useSelector(state => state.upload);

    // const handleUploadClick = event => {
    //     let file = event.target.files[0];
    //     const imageData = new FormData();
    //     imageData.append('imageFile', file);
    //     setImageData(imageData);
    //     // setImagePreview(URL.createObjectURL(file));
    // };

    // const uploadImageWithAdditionalData = () => {
    //     imageData.append('imageName', imageName);
    //     dispatch(uploadImage(imageData));
    // };

    // const handleChange = event => {
    //     setImageName(event.target.value)
    // };
    // 1.uploadImageWithAdditionalData()
    // 2.handleUploadClick
    // 3.handleChange

    const [val, setVal] = useState("");

    let navigate = useNavigate;
    async function lol() {

        let name = document.getElementById("name").value;
        document.getElementById("name").value = "";

        let file = document.getElementById("file").files[0];
        document.getElementById("file").value = "";

        let company = document.getElementById("company").value;
        document.getElementById("company").value = "";
        let year = document.getElementById("year").value;
        document.getElementById("year").value = "";
        let url = "http://localhost:9999/aalumni";
        let Alumnimodel = {
            "name": name,

            "file": file,
            "company": company,
            "year": year
        }


        const formData = new FormData();

        for (const name in Alumnimodel) {
            formData.append(name, Alumnimodel[name]);
        }

        const response = await fetch(url, {
            method: 'POST',
            body: formData
        });
        navigate("/alumni");
        setVal("name");

    }
    return (
        <div>
            {/* <HeaderNV /> */}
            <div style={{ background: "Pink Pearl", height: "800px", borderRadius: "50px" }}>
                <div className="forma" style={{ textAlign: "center" }}>
                    <section >

                        <h2 style={{ textAlign: "center" }}>Add Alumni Details:</h2>

                        <div style={{
                            background: "grey", width: "475px", height: "250px"
                        }}>
                            <form >
                                <input type="file" id="file" onChange={handleChange} />
                                <img src={file} id="file" style={{ height: "100px", width: "120px" }} /> <br />
                                <label>Name</label>
                                <input type="text" name="name" placeholder="Alumni name" id="name" /> <br />

                                <label> company</label>
                                <input id="company" type="text" name="tbranch" placeholder="company" /> <br />

                                <label>year</label>
                                {/* <input id="exp" type="text" name="experience" placeholder="Experience" /> <br /> */}

                                <input id="year" type="number" min="1900" max="2099" step="1" /> <br />

                                <input type="submit" value="Save teacher" onClick={lol} style={{ textAlign: "right" }} />
                            </form>
                            <a href="/teacher">Back to Alumni List</a>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    );
}




export default Addalu;