import axios from "axios";
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./styletr.css";
import "./icons";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
//import { solid, regular, brands, icon } from '@fortawesome/fontawesome-svg-core/import.macro'
//import { IconName } from "react-icons/fa";
//import "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css";

//import { useNavigate } from "react-router-dom";


const Registerr = () => {
  let navigate = useNavigate();

  const [data, setData] = useState({
    regd: "",
    name: "",
    email: "",
    password: "",



  });
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState(false);



  const onInputChange = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });
    // e.preventDefault();
    // if (regd === '' || name === '' || email === '' || pass === '') {
    //   setError(true);
    // } else {
    //   setSubmitted(true);
    //   setError(false);
    // }
  };

  const successMessage = () => {
    return (
      <div
        className="success"
        style={{
          display: submitted ? '' : 'none',
          color: "cyan"
        }}>
        <h1>User {name} successfully registered!!</h1>
      </div>
    );
  };

  // Showing error message if error is true
  const errorMessage = () => {
    return (
      <div
        className="error"
        style={{
          display: error ? '' : 'none',
          color: "red"
        }}>
        <h1>Please enter all the fields</h1>
      </div>
    );
  };


  const { regd, name, email, password } = data;
  const onSubmit = async (e) => {
    e.preventDefault();
    if (regd === '' || name === '' || email === '' || password === '') {
      setError(true);
    } else {
      setSubmitted(true);
      setError(false);
    }
    console.log(regd, name, email, password)
    e.preventDefault();
    await axios.post("http://localhost:9999/reg", data);
    navigate("/");
  };
  return (
    



    








    <div className="form">
      <form onSubmit={(e) => onSubmit(e)}>
        {/* Registration No.<input type="text" placeholder="Regd ID" name="regd" value={regd} onChange={(e) => onInputChange(e)}/> <br></br>
        Name<input type="text" placeholder="Name" name="name" value={name} onChange={(e) => onInputChange(e)}/> <br></br>
        E-Mail<input type="email" placeholder="Email" name="email" value={email} onChange={(e) => onInputChange(e)}/> <br></br>
        Password<input type="password" placeholder="Password" name="pass"  value={pass} onChange={(e) => onInputChange(e)}/> <br></br> */}
        <div className="messages">

        </div>
        
        <div className="area" >
            <ul className="circles">
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
            </ul>
    </div >
       



        {/* <form> */}

        <div className="containertr">



          <div className="message">
            {errorMessage()}
            {successMessage()}
          </div>

          <form method="post" autocomplete="on">
            <div className="boxtr">
              <label htmlFor="regd" className="fl fontLabel"> Registration No: </label>
              <div className="new iconBox">
                <FontAwesomeIcon icon="fa-solid fa-user" aria-hidden="true" />
              </div>
              <div className="fr">
                <input type="text" required
                  name="regd" placeholder="Regd no."
                  className="textBoxtr" value={regd} onChange={(e) => onInputChange(e)} />
              </div>
              <div className="clr"></div>
            </div>


            <div className="boxtr">
              <label htmlFor="name" className="fl fontLabel"> Name: </label>
              <div className="fl iconBox"><FontAwesomeIcon icon="fa-solid fa-user" aria-hidden="true" /></div>
              <div className="fr">
                <input type="text" required name="name"
                  placeholder="Name" className="textBoxtr" value={name} onChange={(e) => onInputChange(e)} />
              </div>
              <div className="clr"></div>
            </div>

            <div className="boxtr">
              <label htmlFor="email" className="fl fontLabel"> Email ID: </label>
              <div className="fl iconBox"><FontAwesomeIcon icon="fa-solid fa-envelope" aria-hidden="true" /></div>
              <div className="fr">
                <input type="email" required name="email" placeholder="Email Id" className="textBoxtr" value={email} onChange={(e) => onInputChange(e)} />
              </div>
              <div className="clr"></div>
            </div>

            <div className="boxtr">
              <label htmlFor="password" className="fl fontLabel"> Password </label>
              <div className="fl iconBox"><FontAwesomeIcon icon="fa-solid fa-key" aria-hidden="true" /></div>
              <div className="fr">
                <input type="Password" required name="password" placeholder="Password" className="textBoxtr" value={password} onChange={(e) => onInputChange(e)} />
              </div>
              <div className="clr"></div>
            </div>



          </form>
          <div className="boss">
            <input type="submit" onClick={onSubmit} className="submittr" value="REGISTER" />
          </div>

          <div className='kiran-links'>
                                <p>Already have an Account ? </p>
                            </div>


                            <div className='kiran-reg'>
                                <Link to='/'>Login</Link>
                            </div>
        </div>




        {/* <input type="submit" value="register"/> */}













      </form>
    </div>
  );

}
export default Registerr