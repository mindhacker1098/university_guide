import Fileupload from './Fileupload';

function Pract() {

    return (



        <div style={{ backgroundcolor: "teal" }}>

            <Fileupload />
        </div >
    )
}

export default Pract