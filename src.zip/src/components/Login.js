import axios from "axios";
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import profil from "./assets/images/logg.jpg";
import './Login.css';
import './styletr.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';



export default function Login() {
    let navi = useNavigate();

    const [user, setUser] = useState({

        email: "",
        password: "",
    });

    const { email, password } = user;

    const onInputChange = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value });
    };

    const onSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.post("http://localhost:9999/loginuser", user);
            navi("/home");
        }
        catch {
            let a = document.getElementById("er");
            a.innerHTML = "Entered Wrong Cerdintals";
            a.style.color = "red";
            a.style.fontWeight = 700;
        }
        // catch (err) {
        //   // Handle error
        //   console.log(err);
    }


    return (

        <div className="area" >
            <ul className="circles">
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
            </ul>

            <div className="containertr">
                <form method="post" autocomplete="on">
                    <div className="boxtr">
                        <label htmlFor="email" className="fl fontLabel"> Email ID: </label>
                        <div className="fl iconBox"><FontAwesomeIcon icon="fa-solid fa-envelope" aria-hidden="true" /></div>
                        <div className="fr">
                            <input type="email" required name="email" placeholder="Email Id" className="textBoxtr" value={email} onChange={(e) => onInputChange(e)} />
                        </div>
                        <div className="clr"></div>
                    </div>


                    <div className="boxtr">
                        <label htmlFor="password" className="fl fontLabel"> Password </label>
                        <div className="fl iconBox"><FontAwesomeIcon icon="fa-solid fa-key" aria-hidden="true" /></div>
                        <div className="fr">
                            <input type="Password" required name="password" placeholder="Password" className="textBoxtr" value={password} onChange={(e) => onInputChange(e)} />
                        </div>
                        <div className="clr"></div>
                    </div>
                </form>

                <div className="boss">
                    <input type="submit" onClick={onSubmit} className="submittr" value="LOGIN" />
                </div>

                <div className='kiran-forget'>
                    <Link to='/forgetp'>Forgot_Password ?</Link>
                </div>

                <div className='kiran-links'>
                    <p>Don't have an Account ? </p>
                </div>


                <div className='kiran-reg'>
                    <Link to='/register'>Register</Link>
                </div>

            </div>
        </div>
    );
};

