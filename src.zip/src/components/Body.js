
import BgVD from "./assets/ccr-Cut.m4v";
function Body() {



    return (

        <>
            <section className="section main-banner" id="top" data-section="section1">
                <video autoPlay loop muted id="bg-video">
                    <source src={BgVD} type="video/mp4"></source>
                </video>

                <div className="video-overlay header-text">
                    <div className="container">
                        <div className="row">
                            <div className="col-lg-12">
                                <div className="caption">
                                    <h6>Hello Students</h6>
                                    <h2>Welcome to Centurion Guide</h2>
                                    <p>
                                        Get solution to all your problems you face in a University,
                                        A guide which will be your patner to dolve your issue.
                                    </p>
                                    {/* <br />
                                    <a href="/pract">backendpractice</a> */}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>

    );

}
export default Body