import './shakthi.css';
import HeaderNV from './Header';

import { useState } from "react";


function Shakthi() {


  const [val, setVal] = useState("");
  async function lol() {

    let name = document.getElementById("name").value;
    document.getElementById("name").value = "";
    let date = document.getElementById("date").value;
    document.getElementById("date").value = "";
    let file = document.getElementById("file").files[0];
    document.getElementById("file").value = "";
    document.getElementById("date").value = "";
    let desp = document.getElementById("desp").value;
    document.getElementById("desp").value = "";
    let plac = document.getElementById("venue").value;
    document.getElementById("venue").value = "";
    let url = "http://localhost:8080/file";
    let data = {
      "name": name,
      "date": date,
      "file": file,
      "desp": desp,
      "plac": plac
    }


    const formData = new FormData();

    for (const name in data) {
      formData.append(name, data[name]);
    }

    const response = await fetch(url, {
      method: 'POST',
      body: formData
    });
    setVal("name");

  }




  return (

    <div>
      <section className="shadow contact-clean" style={{ background: "rgb(3, 77, 139)" }}>
        <form className="bg-light border rounded border-secondary shadow-lg" method="post" style={{ background: "rgb(248, 248, 249)" }}>
          <h2 className="text-center">Add Event</h2>
          <div className="form-group mb-3"><input className="form-control" type="text" name="name" placeholder="Name" id="name" /></div>
          <div className="form-group mb-3"><input className="form-control" type="text" name="venue" placeholder="Venue" id="venue" /></div>
          <div className="form-group mb-3"><input className="form-control" type="date" id="date" /></div>
          <div className="form-group mb-3"><input className="form-control" type="file" id="file" /></div>
          <div className="form-group mb-3"><textarea className="form-control" name="message" placeholder="Description" rows="14" id="desp"></textarea></div>
          <div className="form-group mb-3"><button className="btn btn-primary" type="button" onClick={lol}>Add</button></div>
          <div className="form-group mb-3"><button className="btn btn-primary" type="button" onClick={lol}>BAck to Event List</button></div>
          <div className="form-group mb-3">
          </div>
        </form>
      </section>
    </div>
  );
}
export default Shakthi