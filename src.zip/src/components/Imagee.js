import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import './Imagee.css'
import HeaderNV from './Header'
// import { useDispatch, useSelector } from "react-redux";
// import { uploadImage } from "./uploadAction";

function Imagee() {
    const [file, setFile] = useState();
    function handleChange(e) {
        console.log(e.target.files);
        setFile(URL.createObjectURL(e.target.files[0]));
    }


    // const Imagee = () => {

    // const classes = useStyles();
    // const dispatch = useDispatch();
    // //const [imagePreview, setImagePreview] = useState(null);
    // const [imageData, setImageData] = useState(null);
    // const [imageName, setImageName] = useState("");
    // //const { image } = useSelector(state => state.upload);

    // const handleUploadClick = event => {
    //     let file = event.target.files[0];
    //     const imageData = new FormData();
    //     imageData.append('imageFile', file);
    //     setImageData(imageData);
    //     // setImagePreview(URL.createObjectURL(file));
    // };

    // const uploadImageWithAdditionalData = () => {
    //     imageData.append('imageName', imageName);
    //     dispatch(uploadImage(imageData));
    // };

    // const handleChange = event => {
    //     setImageName(event.target.value)
    // };
    // 1.uploadImageWithAdditionalData()
    // 2.handleUploadClick
    // 3.handleChange

    const [val, setVal] = useState("");

    let navigate = useNavigate;
    async function lol() {

        let name = document.getElementById("name").value;
        document.getElementById("name").value = "";

        let file = document.getElementById("file").files[0];
        document.getElementById("file").value = "";

        let branch = document.getElementById("branch").value;
        document.getElementById("branch").value = "";
        let exp = document.getElementById("exp").value;
        document.getElementById("exp").value = "";
        let url = "http://localhost:9999/aalumni";
        let Techmodel = {
            "name": name,

            "file": file,
            "branch": branch,
            "exp": exp
        }


        const formData = new FormData();

        for (const name in Techmodel) {
            formData.append(name, Techmodel[name]);
        }

        const response = await fetch(url, {
            method: 'POST',
            body: formData
        });
        navigate("/home");
        setVal("name");

    }
    return (
        <div>
            {/* <HeaderNV /> */}
            <div style={{ background: "teal", height: "800px" }}>
                <div className="forma" style={{ textAlign: "center" }}>
                    <section >

                        <h2 style={{ textAlign: "center" }}>Add Teacher Details:</h2>

                        <div style={{
                            background: "grey", width: "475px", height: "250px"
                        }}>
                            <form >
                                <input type="file" id="file" onChange={handleChange} />
                                <img src={file} id="file" style={{ height: "100px", width: "120px" }} /> <br />
                                <label>Name</label>
                                <input type="text" name="name" placeholder="teacher name" id="name" /> <br />

                                <label> branch</label>
                                <input id="branch" type="text" name="branch" placeholder="branch" /> <br />

                                <label>Experience</label>
                                <input id="exp" type="text" name="experience" placeholder="Experience" /> <br />
                                <input type="submit" value="Save teacher" onClick={lol} style={{ textAlign: "right" }} />
                            </form>
                            <a href="/teacher">Back to Teacher List</a>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    );
}

export default Imagee;