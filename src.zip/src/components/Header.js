import EVentList from "./Event-list";
import MaterialMT from "./Material";
import { Link, BrowserRouter as Router, Routes, Route, useNavigate } from "react-router-dom";

function Header() {
	// const navigate = useNavigate();

	// const navigateToContacts = () => {
	// 	// 👇️ navigate to /contacts
	// 	navigate('/event');
	// };

	return (
		<div>



			<header className="header-area header-sticky">
				<div className="container">
					<div className="row">
						<div className="col-12">
							<nav className="main-nav">
								<a href="/home" className="logo">
									Centurion University
								</a>

								<ul className="nav">
									<li className="vt">
										<a
											href="https://tour.concept3d.com/share/7dMdHnQyg/stop/1?mv"
											className="active"
										>
											Virtual Tour
										</a>
									</li>
									<li className="scroll-to-section">
										<a href="/meeting">Events</a>
									</li>

									<li className="has-sub">
										<a href="#mics">mics</a>
										<ul className="sub-menu">
											<li>
												<a href="/alumni">Alumni</a>
											</li>
											<li>
												<a href="/teacher">Teachers</a>
											</li>
											<li>
												<a href="/view">Emergency_Contacts</a>
											</li>
										</ul>
									</li>
									<li className="mat">
										<a href="/material">Material</a>
									</li>
									<li className="has-sub">
										<a href="#mics">profile</a>
										<ul className="sub-menu">
											<li>
												<a href="/">Login</a>
											</li>
											<li>
												<a href="/register">Register</a>
											</li>
										</ul>
									</li>
									<li className="mat">
										<a href="/pract">practice</a>
									</li>
								</ul>
							</nav>
						</div>
					</div>
				</div>
			</header>

		</div>
	);
}

export default Header;
