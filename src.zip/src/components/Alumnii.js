import "./Alumnii.css";
import BG from "./assets/course.png";
import CUTMLOGO from "./assets/CUTM_Logo-removebg-preview.png"
// import "./Icon.css"

import TCON from "./assets/DINESH-SHARMA-3.jpg"
import TCTW from "./assets/PP_recent.jpg"
import HeaderNV from './Header'

function Alumni() {
    return (
        <div>

            <HeaderNV />
            <section className="meetings-page" id="meetings" >





                <div className="container">
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="row">
                                <div className="col-lg-12">
                                    <div className="filters">
                                        <ul>
                                            <li data-filter="*" className="active">
                                                All Alumni
                                            </li>
                                            <li data-filter=".soon">2020</li>
                                            <li data-filter=".imp">2019</li>
                                            <li data-filter=".att">2021</li>
                                            <li ><a href="/addalu">Add Alumni</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>




                <div class="grid-containerr">
                    <div>
                        <img class='grid-item grid-item-1' src='https://images.pexels.com/photos/7944067/pexels-photo-7944067.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1' alt='' />
                        <p>"I'm so happy today!"</p>
                    </div>
                    <div>
                        <img class='grid-item grid-item-2' src='https://images.pexels.com/photos/7944044/pexels-photo-7944044.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1' alt='' />
                        <p>"I see those nugs."</p>
                    </div>
                    <div>
                        <img class='grid-item grid-item-3' src='https://images.pexels.com/photos/7944065/pexels-photo-7944065.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1' alt='' />
                        <p>"I love you so much!"</p>
                    </div>
                    <div>
                        <img class='grid-item grid-item-4' src='https://images.pexels.com/photos/2495235/pexels-photo-2495235.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1' alt='' />
                        <p>"I'm the baby of the house!"</p>
                    </div>
                    <div>
                        <img class='grid-item grid-item-5' src='https://images.pexels.com/photos/3660654/pexels-photo-3660654.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1' alt='' />
                        <p>"Are you gunna throw the ball?"</p>
                    </div>
                    <div>
                        <img class='grid-item grid-item-6' src='https://images.pexels.com/photos/7944063/pexels-photo-7944063.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1' alt='' />
                        <p>"C'mon friend!"</p>
                    </div>
                    <div>
                        <img class='grid-item grid-item-7' src='https://images.pexels.com/photos/7942545/pexels-photo-7942545.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1' alt='' />
                        <p>"A rose for mommy!"</p>
                    </div>
                    <div>
                        <img class='grid-item grid-item-8' src='https://images.pexels.com/photos/7944047/pexels-photo-7944047.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1' alt='' />
                        <p>"You gunna finish that?"</p>
                    </div>
                    <div>
                        <img class='grid-item grid-item-9' src='https://images.pexels.com/photos/2495233/pexels-photo-2495233.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1' alt='' />
                        <p>"We can't afford a cat!"</p>
                    </div>
                    <div>
                        <img class='grid-item grid-item-10' src={'https://images.pexels.com/photos/7944052/pexels-photo-7944052.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'} alt='' />
                        <p>"Dis my fren!"</p>
                    </div>
                </div>


            </section >




        </div >

    );
}

export default Alumni;


{/* <div className="picc">
                        <div className="picdes">
                            <img src="elon.jfif" alt="Avatar" class="image" style="width:100%">
                            <img src={TCON} alt="Avatar" className="image" style={{ width: "100%" }} />

                            <div className="textt">
                                Name: <a>elon</a>
                                Year:<a>2021</a>
                                Branch:<a>cse</a>
                            </div>


                        </div>
                    </div>  */}