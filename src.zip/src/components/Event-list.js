import bgNet from "./assets/backcent.jpg";
import HeaderNV from "./Header";

function EVentList() {
	return (
		<div>
			{/* <header className="header-area header-sticky">
				<div className="container">
					<div className="row">
						<div className="col-12">
							<nav className="main-nav">
								<a href="index.html" class="logo">
									Centurion University
								</a>
								<ul className="nav">
									<li className="vt">
										<a
											href="https://tour.concept3d.com/share/7dMdHnQyg/stop/1?mv"
											class="active"
										>
											Virtual Tour
										</a>
									</li>
									<li className="scroll-to-section">
										<a href="#meetings">Events</a>
									</li>
									<li className="has-sub">
										<a href="http://cutm.ac.in">mics</a>
										<ul className="sub-menu">
											<li>
												<a href="#almuni.html">Alumni</a>
											</li>
											<li>
												<a href="#teachers.html">Teachers</a>
											</li>
										</ul>
									</li>
									<li className="mat">
										<a href="material.html">Material</a>
									</li>
									<li className="pro">
										<a href="#profile.html">Profile</a>
									</li>
								</ul>
								<a href="http://cutm.ac.in" className="menu-trigger">
									<span>Menu</span>
								</a>
							</nav>
						</div>
					</div>
				</div>
			</header> */}
			<HeaderNV />
			<section className="meetings-page" id="meeting">
				<div className="container">
					<div className="row">
						<div className="col-lg-12">
							<div className="row">
								<div className="cil-lg-12">
									<div className="meeting-single-item">
										<div className="thumb">
											<div className="price">
												<span>Monday</span>
											</div>
											<div className="date">
												<h6>Nov</h6>
												<span>12</span>
											</div>
											<a href="meeting-details.html">
												<img src={bgNet} alt="" />
											</a>
										</div>
										<div className="down-content">
											<a href="meeting-details.html">
												<h4>College fest</h4>
											</a>
											<p>R.Sitapur, gajapati, odisha, India</p>
											<p className="description"></p>
											<div className="row">
												<div className="col-lg-4">
													<div className="hours">
														<h5>Hours</h5>
														<p>
															Monday - Friday: 07:00 AM - 13:00 PM
															<br />
															Saturday- Sunday: 09:00 AM - 15:00 PM
														</p>
													</div>
												</div>
												<div className="col-lg-4">
													<div className="location">
														<h5>Location</h5>
														<p>
															R. Sitapur,
															<br />
															Odisha, pin-761211, odisha
														</p>
													</div>
												</div>
												<div className="col-lg-8">
													<div className="book-now">
														<h5>Book Now</h5>
														<p>
															010-020-0340
															<br />
															090-080-0760
														</p>
													</div>
												</div>
												<div className="col-lg-12">
													<div className="share">
														<h5>Share:</h5>
														<ul>
															<li>
																<a href="https://share">Facebook</a>,
															</li>
															<li>
																<a href="https://share">Twitter</a>,
															</li>
															<li>
																<a href="https://share">Linkedin</a>,
															</li>
															<li>
																<a href="https://share">Behance</a>
															</li>
														</ul>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div className="col-lg-12">
									<div className="main-button-red">
										<a href="/eventlist">Back To Meetings List</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		</div>
	);
}
export default EVentList;
