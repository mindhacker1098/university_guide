// import WAVE from "./assets/wave.png";
import "./footer.css";
function Footer() {
	return (
		<div>
			<footer>
				<div className="footer-waves">
					<div className="wave" id="wave1"></div>
					<div className="wave" id="wave2"></div>
					<div className="wave" id="wave3"></div>
					<div className="wave" id="wave4"></div>
				</div>
				<ul>
					<li>
						<a href="#home">
							<img className="footer-icons" src="./instagram.png" alt="Instagram" />
						</a>
					</li>
					<li>
						<a href="#home">
							<img className="footer-icons" src="./instagram.png" alt="Instagram" />
						</a>
					</li>
					<li>
						<a href="#home">
							<img className="footer-icons" src="./instagram.png" alt="Instagram" />
						</a>
					</li>
					<li>
						<a href="#home">
							<img className="footer-icons" src="./instagram.png" alt="Instagram" />
						</a>
					</li>
				</ul>
				<ul className="footer-links">
					<li>
						<a className="footer-link" href="#home">
							Home
						</a>
					</li>
					<li>
						<a className="footer-link" href="#home">
							Portfolio
						</a>
					</li>
					<li>
						<a className="footer-link" href="#home">
							Contact
						</a>
					</li>
				</ul>
			</footer>
		</div>
	);
}

export default Footer;
