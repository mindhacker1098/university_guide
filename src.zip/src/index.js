import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
// import MaterialMT from './components/Material';
// import EVentList from './components/Event-list';


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
    {/* <MaterialMT/> */}
    {/* <EVentList/> */}
  </React.StrictMode>
);

