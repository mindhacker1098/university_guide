
import './App.css';
import HeaderNV from './components/Header';
import EventCUTM from './components/Events';
import Alumnii from './components/Alumnii';
import FooterFT from './components/Footer';
import Material from './components/Material';
import { Link, BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Body from './components/Body';
import Home from './components/Home';
import EVentList from './components/Event-list';
import Alumni from './components/Alumnii';
import Meeting from './components/Meeting';
import Pract from './components/Pract';
import Teacher from './components/Teacher';
import Login from './components/Login';
import Imagee from './components/Imagee'
import Shakthi from './components/Shakthi';
import Addalu from './components/addalu';
import Registerr from './components/registers';
import Fileupload from './components/Fileupload';
import View from './components/View';
import Adde from './components/Add';

// import RegistrationForm from './components/RegistrationForm';
function App() {
  return (
    <div>
      <Router>

        {/* <Link className="btn btn-outline-light" to="/adduser">
Register
</Link><br></br>
<Link className="btn btn-outline-light" to="/material">
Material
</Link><br></br> */}
        {/* <Link className="btn btn-outline-light" to="/log">
Login
</Link> */}

        <Routes>

          <Route exact path="/alumni" element={<Alumni />} />
          <Route exact path="/register" element={<Registerr />} />


          {/* <Route exact path="/edituser/:id" element={<EditUser />} />
<Route exact path="/viewuser/:id" element={<ViewUser />} /> */}

          <Route exact path="/material" element={<Material />} />
          <Route exact path="/teacher" element={<Teacher />} />
          <Route exact path="/meeting" element={<Meeting />} />
          <Route exact path="/eventlist" element={<EVentList />} />
          <Route exact path="/home" element={<Home />} />
          <Route exact path="/pract" element={<Pract />} />
          <Route exact path="/" element={<Login />} />
          <Route exact path="/add" element={<Imagee />} />
          <Route exact path="/HeaderNV" element={<HeaderNV />} />
          <Route exact path="/adda" element={<Shakthi />} />
          <Route exact path="/ada" element={<Imagee />} />
          <Route exact path="/addalu" element={<Addalu />} />
          <Route exact path="/addmat" element={<Pract />} />
          <Route exact path="/view" element={<View />} />
          <Route exact path="/adde" element={<Adde />} />
          {/* <Route exact path="/" element={<Loginn />} /> */}

        </Routes>

      </Router>





      {/* <MaterialMT /> */}
      {/* <FooterFT /> */}


    </div>
  );
}

export default App;
